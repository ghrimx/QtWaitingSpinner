Waiting spinner for PyQt5
